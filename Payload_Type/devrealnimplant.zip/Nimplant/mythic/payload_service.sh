#!/bin/bash

cd /Mythic/mythic

export PYTHONPATH=/Mythic:/Mythic/mythic

python3.8 mythic_service.py